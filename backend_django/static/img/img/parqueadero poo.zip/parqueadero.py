class Parqueadero:

    def __init__(self, codigo_parqueo, fecha, placa, marca, color, codigo_propietario, nombre_propietario, hora_ingreso):
        self.codigo_parqueo = codigo_parqueo
        self.fecha = fecha
        self.placa = placa
        self.marca = marca
        self.color = color
        self.codigo_propietario = codigo_propietario  
        self.nombre_propietario = nombre_propietario
        self.hora_ingreso = hora_ingreso
        self.hora_salida = None
        self.valor_pagar = 0

    def mostrar_info(self):
        print("*******************************************")
        print("Código parqueo:", self.codigo_parqueo)
        print("Fecha:", self.fecha)
        print("Placa:", self.placa)
        print("Marca:", self.marca)
        print("Color:", self.color)
        print("Código propietario:", self.codigo_propietario)
        print("Nombre propietario:", self.nombre_propietario)
        print("Hora ingreso:", self.hora_ingreso)
        print("Hora salida:", self.hora_salida)
        print("Valor a pagar:", self.valor_pagar)
