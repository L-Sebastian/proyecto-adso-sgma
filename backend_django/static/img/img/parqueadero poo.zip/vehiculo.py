class Vehiculo:

    def __init__(self, placa, marca, modelo, color, codigo_propietario, nombre_propietario):
        self.placa = placa
        self.marca = marca
        self.modelo = modelo
        self.color = color
        self.codigo_propietario = codigo_propietario
        self.nombre_propietario = nombre_propietario    

    def mostrar_info(self):
        print("*****************************************")
        print(f"Placa: {self.placa}")
        print(f"Marca: {self.marca}")
        print(f"Modelo: {self.modelo}")
        print(f"Color: {self.color}")
        print(f"Código propietario: {self.codigo_propietario}")
        print(f"Nombre propietario: {self.nombre_propietario}")
        print("*******************************************")
