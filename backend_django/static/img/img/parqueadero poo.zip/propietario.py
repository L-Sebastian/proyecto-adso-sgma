class Propietario:

    def __init__(self, codigo_propietario, nombre, telefono, correo_electronico):
        self.codigo_propietario = codigo_propietario
        self.nombre = nombre
        self.telefono = telefono
        self.correo_electronico = correo_electronico

    def mostrar_info(self):
        print("********************************")
        print(f"Código propietario: {self.codigo_propietario}")
        print(f"Nombre: {self.nombre}")
        print(f"Teléfono: {self.telefono}")
        print(f"Correo electrónico: {self.correo_electronico}")
