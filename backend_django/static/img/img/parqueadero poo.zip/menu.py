from os import system

from propietario import Propietario
from vehiculo import Vehiculo
from parqueadero import Parqueadero
from datetime import datetime, timedelta
import math

class Menu:
	
	
	# Define la capacidad total del parqueadero como atributo de clase
	
	CAPACIDAD_TOTAL = 10 # Valor configurable - capacidad máxima de vehículos
	
	# Valor por hora o fracción de hora 
	VALOR_HORA = 2800 # Precio en pesos por cada hora o fracción

	def __init__(self):
		"""
		
		"""
		self.propietarios = []  # Lista para almacenar objetos Propietario
		self.vehiculos = []     # Lista para almacenar objetos Vehiculo
		self.parqueaderos = []  # Lista para almacenar objetos Parqueadero

	# ====================== MENÚ PRINCIPAL ======================
	def mostrar_menu(self):
		
		while True:
			
			system("cls")
			
			print("**********************************")
			print("PARQUEADERO DON IMBACHI")
			print("**********************************")
			print("MENU")
			print("**********************************")
			
			print("1. Registrar propietario.")
			print("2. Listar propietarios.")
			print("3. Visualizar propietario.")
			print("4. Modificar propietario.")
			print("5. Eliminar propietario.")
			
			print("6. Registrar vehiculo.")
			print("7. Listar vehiculo.")
			print("8. Visualizar vehiculo.")
			print("9. Modificar vehiculo.")
			print("10. Eliminar vehiculo.")
			
			print("11. Registrar parqueo (Entrada/Salida).") 
			print("12. Listar parqueo.") 
			print("13. Visualizar parqueo.") 
			print("14. Modificar parqueo.")
			print("15. Eliminar parqueo.")
			
			print("16. Generar reporte vehiculos parqueados")
			print("17. Generar reporte espacios disponibles")
			print("18. Generar reporte pagos recibidos")
			print("0. Salir del menu.")
			
			try:
				
				opcion = int(input("Ingrese la opción deseada: "))
				print("*******************************************")
				
				
				if opcion == 1: self.registrar_propietario()
				elif opcion == 2: self.listar_propietario()
				elif opcion == 3: self.visualizar_propietario()
				elif opcion == 4: self.modificar_propietario()
				elif opcion == 5: self.eliminar_propietario()
				elif opcion == 6: self.registrar_vehiculo()
				elif opcion == 7: self.listar_vehiculo()
				elif opcion == 8: self.visualizar_vehiculo()
				elif opcion == 9: self.modificar_vehiculo()
				elif opcion == 10: self.eliminar_vehiculo()
				elif opcion == 11: self.registrar_parqueo()
				elif opcion == 12: self.listar_parqueo()
				elif opcion == 13: self.visualizar_parqueo()
				elif opcion == 14: self.modificar_parqueo()
				elif opcion == 15: self.eliminar_parqueo()
				elif opcion == 16: self.generar_reporte_vehiculos_parqueados()
				elif opcion == 17: self.generar_reporte_espacios_disponibles()
				elif opcion == 18: self.generar_reporte_ingresos() 
				elif opcion == 0: break  # Termina el bucle y sale del programa
				else:
					# Opción no válida (fuera del rango 0-18)
					print("Error - opción no válida")
					input("Presione Enter para continuar...")
			except ValueError:
				
				print("Error - Dato no válido")
				input("Presione Enter para continuar...")

	def validar_numero(self, mensaje):
		"""
		Valida que la entrada del usuario sea un número entero positivo.
		
		Args:
			mensaje (str): Mensaje a mostrar al usuario para solicitar el dato
			
		Returns:
			int: Número entero positivo validado
		"""
		while True:
			# Solicita la entrada y elimina espacios en blanco
			valor = input(mensaje).strip()
			# Verifica que todos los caracteres sean dígitos
			if valor.isdigit():
				# Convierte a entero y verifica que sea mayor que 0
				if int(valor) > 0:
					return int(valor)
				else:
					print("Error - no se permiten valores negativos ni 0")
			else:
				print("Error - debe ingresar solo números enteros positivos")
	
	def validar_letras(self, mensaje):
		
		while True:
			# Solicita la entrada y elimina espacios en blanco al inicio y final
			valor = input(mensaje).strip()
			# Remueve espacios internos temporalmente para validar solo letras
			if valor.replace(' ', '').isalpha(): # Permite espacios pero solo letras
				return valor.capitalize()  # Convierte primera letra a mayúscula
			else:
				print("Error - Solo puede contener letras y espacios.")

	# ====================== PROPIETARIOS ======================
	def registrar_propietario(self):
		"""
		Registra un nuevo propietario en el sistema.
		Valida que no existan códigos duplicados y que los datos cumplan los requisitos.
		"""
		system("cls")  # Limpia la pantalla
		print("=== REGISTRAR PROPIETARIO ===")
		
		# Validar que el código del propietario no esté duplicado
		while True:
			codigo_propietario = self.validar_numero("Digite el código del propietario: ")
			es_duplicado = False
			# Recorre la lista de propietarios para verificar duplicados
			for p in self.propietarios:
				if p.codigo_propietario == codigo_propietario:
					es_duplicado = True
					break  # Sale del bucle si encuentra duplicado
			if es_duplicado:
				print("Error - ya existe un propietario con ese código.")
			else:
				break  # Sale del bucle si no hay duplicado

		# Requisito 32: Nombre con validación de solo letras
		nombre = self.validar_letras("Ingrese el nombre del propietario: ")

		# Requisito 33: Teléfono con validación de 10 dígitos numéricos
		while True:
			telefono = input("Teléfono del propietario (10 dígitos): ")
			# Verifica que sean exactamente 10 dígitos numéricos
			if telefono.isdigit() and len(telefono) == 10:
				break
			else:
				print("Error - debe tener 10 dígitos numéricos")

		# Solicita el correo electrónico (sin validación específica en este código)
		correo_electronico = input("Correo electrónico del propietario: ")

		# Crea el objeto Propietario y lo agrega a la lista
		propietario = Propietario(codigo_propietario, nombre, telefono, correo_electronico)
		self.propietarios.append(propietario)
		print(" Propietario registrado satisfactoriamente.")
		input("Enter para continuar...")

	def listar_propietario(self):
		"""
		Muestra una lista de todos los propietarios registrados en el sistema.
		Si no hay propietarios, muestra un mensaje informativo.
		"""
		system("cls")
		print("=== LISTAR PROPIETARIOS ===")
		# Verifica si la lista está vacía
		if not self.propietarios:
			print("No hay propietarios registrados.")
		# Itera sobre todos los propietarios y muestra su información
		for propietario in self.propietarios:
			print("-----------------------------")
			print(f"Código: {propietario.codigo_propietario}")
			print(f"Nombre: {propietario.nombre}")
			
		input("Enter para continuar...")

	def visualizar_propietario(self):
		"""
		Muestra la información detallada de un propietario específico.
		Busca el propietario por su código único.
		"""
		system("cls")
		print("=== VISUALIZAR PROPIETARIO ===")
		try:
			# Intenta convertir la entrada a entero
			codigo_propietario = int(input("Ingrese el código del propietario: "))
		except ValueError:
			# Maneja el error si no es un número válido
			print("Error - Debe ingresar un número entero")
			input("Enter para continuar...")
			return

		encontrado = None
		# Busca el propietario con el código especificado
		for propietario in self.propietarios:
			if propietario.codigo_propietario == codigo_propietario:
				encontrado = propietario
				break  # Sale del bucle cuando encuentra el propietario

		# Muestra la información si encontró el propietario
		if encontrado:
			print("-----------------------------")
			print(f"Código: {encontrado.codigo_propietario}")
			print(f"Nombre: {encontrado.nombre}")
			print(f"Teléfono: {encontrado.telefono}")
			print(f"Correo: {encontrado.correo_electronico}")
		else:
			print("No se encontró un propietario con ese código")
		input("Enter para continuar...")

	def modificar_propietario(self):
		"""
		Permite modificar los datos de un propietario existente.
		No permite modificar el código del propietario (clave primaria).
		"""
		system("cls")
		print("=== MODIFICAR PROPIETARIO ===")
		try:
			codigo_propietario = int(input("Ingrese el código del propietario a modificar: "))
		except ValueError:
			print("Error - Debe ingresar un número entero")
			input("Enter para continuar...")
			return

		# Busca el propietario a modificar
		for propietario in self.propietarios:
			if propietario.codigo_propietario == codigo_propietario:
				# Permite modificar el nombre con validación de solo letras
				propietario.nombre = self.validar_letras("Nuevo nombre: ")
				
				# Permite modificar el teléfono con validación
				while True:
					telefono = input("Nuevo teléfono (10 dígitos): ")
					if telefono.isdigit() and len(telefono) == 10:
						propietario.telefono = telefono
						break
					else:
						print("Error - Teléfono inválido (debe tener 10 dígitos numéricos).")
				
				# Permite modificar el correo electrónico
				propietario.correo_electronico = input("Nuevo correo: ")
				print(" Propietario modificado correctamente.")
				input("Enter para continuar...")
				return
		
		# Si no encuentra el propietario
		print("No existe un propietario con ese código.")
		input("Enter para continuar...")

	def eliminar_propietario(self):
		"""
		Elimina un propietario del sistema.
		Busca por código y remueve el objeto de la lista.
		"""
		system("cls")
		print("=== ELIMINAR PROPIETARIO ===")
		try:
			codigo_propietario = int(input("Ingrese el código del propietario: "))
		except ValueError:
			print("Error - Debe ingresar un número entero")
			input("Enter para continuar...")
			return
		
		# Busca y elimina el propietario
		for propietario in self.propietarios:
			if propietario.codigo_propietario == codigo_propietario:
				self.propietarios.remove(propietario)  # Remueve de la lista
				print(" Propietario eliminado correctamente.")
				input("Enter para continuar...")
				return
		
		print("No existe un propietario con ese código.")
		input("Enter para continuar...")

	# ====================== VEHICULOS ======================
	def registrar_vehiculo(self):
		"""
		Registra un nuevo vehículo en el sistema.
		Valida todos los datos según los requisitos y verifica que el propietario exista.
		"""
		system("cls")
		print("=== REGISTRAR VEHICULO ===")

		# --- Validar placa (Requisito 41 y verificar duplicados) ---
		while True:
			placa = input("Placa ").upper().strip()
			# Verifica que la longitud esté entre 5 y 6 caracteres
			if not (5 <= len(placa) <= 6):
				print(" Error - La placa debe tener entre 5 y 6 caracteres.")
				continue
			
			# Verifica que no exista otra placa igual
			es_duplicado = False
			for v in self.vehiculos:
				if v.placa == placa:
					es_duplicado = True
					break
			if es_duplicado:
				print(" Error - Ya existe un vehículo registrado con esa placa.")
			else:
				break  # Placa válida y única

		# --- Validar marca (Requisito 42) ---
		marca = self.validar_letras("Marca: ")

		# --- Validar modelo (Requisito 43) ---
		while True:
			modelo_str = input("Modelo ").strip()
			# Verifica que sea un número entero positivo
			if modelo_str.isdigit() and int(modelo_str) > 0:
				modelo = int(modelo_str)
				break
			else:
				print(" Error - El modelo debe ser un número positivo.")
		
		# --- Validar color (Requisito 44) ---
		color = self.validar_letras("Color: ")

		# --- Validar código propietario (Requisito 45) ---
		codigo_propietario = self.validar_numero("Código del propietario: ")

		# --- Buscar propietario (Requisito 80) ---
		propietario_encontrado = None
		for propietario in self.propietarios:
			if propietario.codigo_propietario == codigo_propietario:
				propietario_encontrado = propietario
				break

		# Verifica que el propietario exista antes de registrar el vehículo
		if not propietario_encontrado:
			print(" Error - No existe propietario con este código. El vehículo no puede ser registrado.")
			input("Enter para continuar...")
			return

		# --- Registrar vehículo ---
		vehiculo = Vehiculo(placa, marca, modelo, color, codigo_propietario, propietario_encontrado.nombre)
		self.vehiculos.append(vehiculo)
		print(" Vehículo registrado satisfactoriamente.")
		input("Enter para continuar...")

	def listar_vehiculo(self):
		"""
		Muestra una lista de todos los vehículos registrados en el sistema.
		"""
		system("cls")
		print("=== LISTAR VEHICULOS ===")
		if not self.vehiculos:
			print("No hay vehículos registrados.")
		# Itera sobre todos los vehículos y muestra su información
		for vehiculo in self.vehiculos:
			print("-------------------------")
			print(f"Placa: {vehiculo.placa}")
			
		input("Enter para continuar...")

	def visualizar_vehiculo(self):
		"""
		Muestra la información detallada de un vehículo específico.
		Busca el vehículo por su placa (identificador único).
		"""
		system("cls")
		print("=== VISUALIZAR VEHICULO ===")
		placa = input("Ingrese la placa: ").upper().strip()
		
		vehiculo_encontrado = None
		# Busca el vehículo con la placa especificada
		for vehiculo in self.vehiculos:
			if vehiculo.placa == placa:
				vehiculo_encontrado = vehiculo
				break

		# Muestra la información si encuentra el vehículo
		if vehiculo_encontrado:
			print("-------------------------")
			print(f"Placa: {vehiculo_encontrado.placa}")
			print(f"Marca: {vehiculo_encontrado.marca}")
			print(f"Modelo: {vehiculo_encontrado.modelo}")
			print(f"Color: {vehiculo_encontrado.color}")
			print(f"Propietario: {vehiculo_encontrado.nombre_propietario}")
		else:
			print("No existe vehículo con esa placa.")
		input("Enter para continuar...")

	def modificar_vehiculo(self):
		"""
		Permite modificar los datos de un vehículo existente.
		No permite modificar la placa (identificador único).
		"""
		system("cls")
		print("=== MODIFICAR VEHICULO ===")
		placa = input("Ingrese la placa del vehículo a modificar: ").upper().strip()
		
		vehiculo_a_modificar = None
		# Busca el vehículo a modificar
		for vehiculo in self.vehiculos:
			if vehiculo.placa == placa:
				vehiculo_a_modificar = vehiculo
				break
				
		if vehiculo_a_modificar:
			print(f"Vehículo encontrado: {vehiculo_a_modificar.marca} {vehiculo_a_modificar.modelo} - {vehiculo_a_modificar.color}")
			print("La placa no se puede modificar.")  # La placa es inmutable
			
			# Modificar marca con validación de letras
			vehiculo_a_modificar.marca = self.validar_letras("Nueva marca: ")
					
			# Modificar modelo con validación de números
			while True:
				nuevo_modelo = input("Nuevo modelo (año): ").strip()
				if nuevo_modelo.isdigit() and int(nuevo_modelo) > 0:
					vehiculo_a_modificar.modelo = int(nuevo_modelo)
					break
				else:
					print(" Error - El modelo debe ser un número positivo.")
					
			# Modificar color con validación de letras
			vehiculo_a_modificar.color = self.validar_letras("Nuevo color: ")
			
			print(" Vehículo modificado con éxito.")
			input("Enter para continuar...")
			return
		
		print(" No existe vehículo con esa placa.")
		input("Enter para continuar...")

	def eliminar_vehiculo(self):
		"""
		Elimina un vehículo del sistema.
		Busca por placa y remueve el objeto de la lista.
		"""
		system("cls")
		print("=== ELIMINAR VEHICULO ===")
		placa = input("Ingrese la placa: ").upper().strip()
		
		# Busca y elimina el vehículo
		for vehiculo in self.vehiculos:
			if vehiculo.placa == placa:
				self.vehiculos.remove(vehiculo)
				print(" Vehículo eliminado correctamente.")
				input("Enter para continuar...")
				return
		
		print("No existe vehículo con esa placa.")
		input("Enter para continuar...")

	# ====================== PARQUEOS ======================
	def registrar_parqueo(self):
		"""
		Gestiona el registro de entrada y salida de vehículos del parqueadero.
		Controla la capacidad total y calcula los pagos por tiempo de estadía.
		"""
		system("cls")
		print("=== REGISTRAR PARQUEO (ENTRADA/SALIDA) ===")

		capacidad_total = Menu.CAPACIDAD_TOTAL 
		# Cuenta los espacios ocupados (parqueos sin hora de salida)
		ocupados = 0
		for p in self.parqueaderos:
			if not p.hora_salida:  # Si no tiene hora de salida, está ocupado
				ocupados += 1

		disponibles = capacidad_total - ocupados
		print(f"Estado actual: {ocupados} ocupados / {disponibles} disponibles (Total: {capacidad_total})")

		# Muestra las opciones disponibles
		print("\n1. Entrada del vehículo (Registrar Parqueo)")
		print("2. Salida del vehículo (Finalizar Parqueo)")
		try:
			opcion = int(input("Opción (1/2): "))
		except ValueError:
			print("Opción inválida.")
			input("Enter para continuar...")
			return

		# ==================== ENTRADA DE VEHÍCULO ====================
		if opcion == 1: # ENTRADA DE VEHÍCULO (Requisito 57)
			if disponibles <= 0: # Requisito 84
				print("  No hay espacios disponibles en el parqueadero.")
				input("Enter para continuar...")
				return
			
			# ===== VALIDAR ID DEL PARQUEO =====
			while True:
				try:
					codigo_parqueo = int(input("Ingrese el ID del parqueo: "))
					if codigo_parqueo <= 0:
						print(" Error - El ID debe ser un número positivo mayor que 0.")
						continue
				except ValueError:
					print(" Error - El ID debe contener solo números.")
					continue

				# Validar duplicado
				duplicado = False
				for p in self.parqueaderos:
					if p.codigo_parqueo == codigo_parqueo:
						duplicado = True
						break
				if duplicado:
					print(" Error - ya existe un parqueo con este ID.")
				else:
					break
			# ================================

			# Fecha y placa
			fecha = datetime.now().date()
			placa = input("Placa del vehículo: ").upper().strip()

			# Validar si el vehículo ya está parqueado
			for p in self.parqueaderos:
				if p.placa == placa and not p.hora_salida:
					print(" Error - Este vehículo ya tiene un parqueo activo.")
					input("Enter para continuar...")
					return

			# Validar que el vehículo esté registrado
			vehiculo_encontrado = None
			for v in self.vehiculos:
				if v.placa == placa:
					vehiculo_encontrado = v
					break

			if not vehiculo_encontrado:
				print(" Error - No existe un vehículo registrado con esa placa.")
				input("Enter para continuar...")
				return

			# Hora de ingreso
			hora_ingreso = datetime.now().strftime("%H:%M:%S")

			# Crear el objeto Parqueadero
			parqueo = Parqueadero(
				codigo_parqueo,
				fecha,
				placa,
				vehiculo_encontrado.marca,
				vehiculo_encontrado.color,
				vehiculo_encontrado.codigo_propietario,
				vehiculo_encontrado.nombre_propietario,
				hora_ingreso
			)
			self.parqueaderos.append(parqueo)
			print(" Entrada registrada correctamente.")
			print(f"Espacios disponibles ahora: {disponibles - 1}")
			input("Enter para continuar...")

		# ==================== SALIDA DE VEHÍCULO ====================
		elif opcion == 2: # Requisito 67
			placa = input("Placa del vehículo a salir: ").upper().strip()
			
			# Buscar el parqueo activo
			parqueo_encontrado = None
			for p in self.parqueaderos:
				if p.placa == placa and not p.hora_salida:
					parqueo_encontrado = p
					break
			
			if not parqueo_encontrado:
				print(" Error - No hay vehículo parqueado activamente con esa placa.")
				input("Enter para continuar...")
				return

			# Hora de salida (manual o actual)
			hora_salida_str = input("Ingrese la hora de salida (HH:MM:SS) o Enter para usar la hora actual: ")
			if not hora_salida_str.strip():
				hora_salida_str = datetime.now().strftime("%H:%M:%S")

			# Validar formato
			formato = "%H:%M:%S"
			try:
				t1 = datetime.strptime(parqueo_encontrado.hora_ingreso, formato)
				t2 = datetime.strptime(hora_salida_str, formato)
			except ValueError:
				print(" Error - Formato de hora inválido. Salida cancelada.")
				input("Enter para continuar...")
				return

			# Validar que la salida no sea antes de la entrada
			diferencia = t2 - t1
			if diferencia.total_seconds() < 0:
				diferencia += timedelta(days=1)

			# Asignar hora de salida
			parqueo_encontrado.hora_salida = hora_salida_str

			# Cálculo de tiempo y cobro
			horas = diferencia.total_seconds() / 3600
			horas_a_cobrar = max(1, math.ceil(horas)) # mínimo 1 hora
			valor = horas_a_cobrar * Menu.VALOR_HORA
			parqueo_encontrado.valor_pagar = valor

			# Resumen
			print("-----------------------------")
			print(" Salida registrada correctamente.")
			print(f"Tiempo total: {horas_a_cobrar} hora(s) cobradas.")
			print(f"Valor a pagar: ${valor}")
			print(f"Espacios disponibles ahora: {disponibles + 1}")
			input("Enter para continuar...")

		else:
			print("Opción inválida.")
			input("Enter para continuar...")


	def listar_parqueo(self):
		"""
		Muestra una lista de todos los vehículos actualmente parqueados.
		Solo muestra parqueos sin hora de salida (activos).
		"""
		system("cls")
		print("=== LISTAR PARQUEOS (ACTIVOS) ===")
		
		# Filtra solo los parqueos activos (sin hora de salida)
		parqueos_activos = []
		for p in self.parqueaderos:
			if not p.hora_salida:
				parqueos_activos.append(p)
		
		if not parqueos_activos:
			print("No hay vehículos parqueados actualmente.")
		else:
			# Muestra información de cada parqueo activo
			for parqueo in parqueos_activos:
				print("-------------------------")
				print(f"Código: {parqueo.codigo_parqueo}")
				print(f"Placa: {parqueo.placa}")
				print(f"Marca: {parqueo.marca}")
				
		input("Enter para continuar...")

	def visualizar_parqueo(self):
		"""
		Muestra el historial completo de parqueos de un vehículo específico.
		Incluye tanto parqueos activos como finalizados.
		"""
		system("cls")
		print("=== VISUALIZAR PARQUEO  ===")
		placa = input("Ingrese la placa: ").upper().strip()
		
		# Busca todos los parqueos asociados a la placa
		encontrados = []
		for p in self.parqueaderos:
			if p.placa == placa:
				encontrados.append(p)
		
		if not encontrados:
			print("No existe un parqueo con esa placa.")
		else:
			print(f"--- Historial de parqueos para la placa {placa} ---")
			# Muestra cada registro de parqueo para esta placa
			for parqueo in encontrados:
				print("-------------------------")
				print(f"Código: {parqueo.codigo_parqueo}")
				print(f"Fecha: {parqueo.fecha}")
				print(f"Marca: {parqueo.marca}")
				print(f"Hora ingreso: {parqueo.hora_ingreso}")
				# Muestra hora de salida o indica si está activo
				salida_estado = parqueo.hora_salida if parqueo.hora_salida else 'En parqueo (Activo)'
				print(f"Hora salida: {salida_estado}")
				# Muestra valor pagado si existe
				if parqueo.valor_pagar:
					print(f"Valor pagado: ${parqueo.valor_pagar}")
		input("Enter para continuar...")

	def modificar_parqueo(self):
	    """
	    Permite modificar datos de un parqueo activo (sin hora de salida).
	    Se pueden modificar todos los atributos excepto el ID del parqueo.
	    Con validaciones: no se permiten valores negativos ni formatos incorrectos.
	    """
	    system("cls")
	    print("=== MODIFICAR PARQUEO (Activo) ===")
	    placa = input("Ingrese la placa del vehículo cuyo parqueo activo desea modificar: ").upper().strip()
	    
	    parqueo_a_modificar = None
	    # Busca el parqueo activo
	    for parqueo in self.parqueaderos:
	        if parqueo.placa == placa and not parqueo.hora_salida:
	            parqueo_a_modificar = parqueo
	            break
	    
	    if not parqueo_a_modificar:
	        print(" Error - No se encontró parqueo activo con esa placa.")
	        input("Enter para continuar...")
	        return
	    
	    print("--- Parqueo Activo Encontrado ---")
	    print("NOTA: No se puede modificar el ID del parqueo.")

	    # ========== Modificar Placa ==========
	    while True:
	        nueva_placa = input(f"Nueva placa ({parqueo_a_modificar.placa}): ").upper().strip()
	        if not nueva_placa:
	            break
	        if 5 <= len(nueva_placa) <= 6:
	            # Validar que la placa exista en vehículos
	            vehiculo_encontrado = None
	            for v in self.vehiculos:
	                if v.placa == nueva_placa:
	                    vehiculo_encontrado = v
	                    break
	            if not vehiculo_encontrado:
	                print(" Error - No existe un vehículo registrado con esa placa.")
	            else:
	                parqueo_a_modificar.placa = nueva_placa
	                parqueo_a_modificar.marca = vehiculo_encontrado.marca
	                parqueo_a_modificar.color = vehiculo_encontrado.color
	                parqueo_a_modificar.codigo_propietario = vehiculo_encontrado.codigo_propietario
	                parqueo_a_modificar.nombre_propietario = vehiculo_encontrado.nombre_propietario
	                print(" Placa y datos del vehículo actualizados.")
	                break
	        else:
	            print(" Advertencia: longitud inválida (5-6 caracteres).")

	    # ========== Modificar Marca ==========
	    nueva_marca = input(f"Nueva marca (Actual: {parqueo_a_modificar.marca}): ").strip()
	    if nueva_marca:
	        if nueva_marca.replace(" ", "").isalpha():  # Solo letras
	            parqueo_a_modificar.marca = nueva_marca
	            print(" Marca modificada.")
	        else:
	            print(" Advertencia: Marca inválida (solo letras).")

	    # ========== Modificar Color ==========
	    nuevo_color = input(f"Nuevo color (Actual: {parqueo_a_modificar.color}): ").strip()
	    if nuevo_color:
	        if nuevo_color.replace(" ", "").isalpha():
	            parqueo_a_modificar.color = nuevo_color
	            print(" Color modificado.")
	        else:
	            print(" Advertencia: Color inválido (solo letras).")

	    # ========== Modificar Código Propietario ==========
	    while True:
	        nuevo_codigo_propietario = input(f"Nuevo código propietario (Actual: {parqueo_a_modificar.codigo_propietario}): ").strip()
	        if not nuevo_codigo_propietario:
	            break
	        try:
	            nuevo_codigo_propietario = int(nuevo_codigo_propietario)
	            if nuevo_codigo_propietario > 0:
	                parqueo_a_modificar.codigo_propietario = nuevo_codigo_propietario
	                print(" Código propietario modificado.")
	                break
	            else:
	                print(" Error - El código propietario no puede ser negativo ni cero.")
	        except ValueError:
	            print(" Error - El código propietario debe ser un número positivo.")

	    # ========== Modificar Nombre Propietario ==========
	    nuevo_nombre = input(f"Nuevo nombre propietario (Actual: {parqueo_a_modificar.nombre_propietario}): ").strip()
	    if nuevo_nombre:
	        if nuevo_nombre.replace(" ", "").isalpha():
	            parqueo_a_modificar.nombre_propietario = nuevo_nombre
	            print(" Nombre propietario modificado.")
	        else:
	            print(" Advertencia: Nombre inválido (solo letras).")

	    # ========== Modificar Fecha ==========
	    nueva_fecha = input(f"Nueva fecha (Actual: {parqueo_a_modificar.fecha} - Formato AAAA-MM-DD): ")
	    if nueva_fecha:
	        try:
	            datetime.strptime(nueva_fecha, "%Y-%m-%d")
	            parqueo_a_modificar.fecha = nueva_fecha
	            print(" Fecha modificada.")
	        except ValueError:
	            print(" Advertencia: Fecha inválida, no se modificó.")

	    # ========== Modificar Hora de Ingreso ==========
	    while True:
	        nueva_hora_ingreso = input(f"Nueva hora ingreso (Actual: {parqueo_a_modificar.hora_ingreso} - Formato HH:MM:SS): ")
	        if not nueva_hora_ingreso:
	            break
	        try:
	            datetime.strptime(nueva_hora_ingreso, "%H:%M:%S")
	            parqueo_a_modificar.hora_ingreso = nueva_hora_ingreso
	            print(" Hora de ingreso modificada.")
	            break
	        except ValueError:
	        	print(" Advertencia: Hora inválida, debe ser HH:MM:SS.")
	        	print(" Parqueo modificado con éxito.")
	        	input("Enter para continuar...")
	        	print("No existe parqueo activo con esa placa para modificar.")
	        	input("Enter para continuar...")

	    		
	    		

			
				
				

	            
	def eliminar_parqueo(self):
		"""
		Elimina un parqueo activo del sistema.
		Solo elimina parqueos que no tienen hora de salida registrada.
		Busca por código del parqueo para evitar ambigüedades.
		"""
		system("cls")
		print("=== ELIMINAR PARQUEO ===")
		# Solicita el código del parqueo para mayor precisión
		try:
			codigo_parqueo = int(input("Ingrese el código del parqueo a eliminar: "))
		except ValueError:
			print("Error - Debe ingresar un número entero")
			input("Enter para continuar...")
			return
			
		parqueo_a_eliminar = None
		# Busca el parqueo activo con el código especificado
		for p in self.parqueaderos:
			if p.codigo_parqueo == codigo_parqueo and not p.hora_salida:
				parqueo_a_eliminar = p
				break
		
		if parqueo_a_eliminar:
			self.parqueaderos.remove(parqueo_a_eliminar)
			print("Parqueo activo eliminado correctamente.")
			input("Enter para continuar...")
			return
			
		print("No existe parqueo *activo* con ese código para eliminar.")
		input("Enter para continuar...")

	# ====================== REPORTES ======================
	def generar_reporte_vehiculos_parqueados(self):
		"""
		Genera un reporte de todos los vehículos actualmente parqueados.
		Muestra información detallada de cada vehículo en el parqueadero.
		"""
		system("cls")
		print("=== REPORTE VEHÍCULOS PARQUEADOS (ACTIVOS) ===")
		
		# Filtra solo los parqueos activos (sin hora de salida)
		vehiculos_activos = []
		for p in self.parqueaderos:
			if not p.hora_salida:
				vehiculos_activos.append(p)
		
		if not vehiculos_activos:
			print("No hay vehículos parqueados actualmente.")
		else:
			print(f"Cantidad de vehículos parqueados: {len(vehiculos_activos)}")
			# Muestra información detallada de cada vehículo parqueado
			for parqueo in vehiculos_activos:
				print("-------------------------")
				print(f"Código Parqueo: {parqueo.codigo_parqueo}")
				print(f"Placa: {parqueo.placa}")
				print(f"Marca: {parqueo.marca}")
				print(f"Color: {parqueo.color}")
				print(f"Propietario: {parqueo.nombre_propietario}")
				print(f"Ingreso: {parqueo.hora_ingreso}")
		input("Enter para continuar...")

	def generar_reporte_espacios_disponibles(self):
		"""
		Genera un reporte del estado de ocupación del parqueadero.
		Muestra capacidad total, espacios ocupados y disponibles.
		"""
		system("cls")
		print("=== REPORTE ESPACIOS DISPONIBLES ===")
		capacidad_total = Menu.CAPACIDAD_TOTAL 
		
		# Cuenta los espacios ocupados (parqueos activos)
		ocupados = 0
		for p in self.parqueaderos:
			if not p.hora_salida:
				ocupados += 1

		disponibles = capacidad_total - ocupados
		
		# Muestra estadísticas del parqueadero
		print(f"Capacidad total del parqueadero: {capacidad_total} espacios")
		print(f"Vehículos parqueados actualmente: {ocupados} vehículos")
		print(f"Espacios disponibles: {disponibles} espacios")
		
		# Indica el estado del parqueadero
		if disponibles == 0:
			print("  El parqueadero está lleno. ")
		elif disponibles > 0:
			print("  Aún hay espacios disponibles. ")
		
		input("Enter para continuar...")

	def generar_reporte_ingresos(self):
		"""
		Genera un reporte de todos los ingresos recibidos por pagos de parqueo.
		Muestra el total de ingresos y el detalle de cada pago.
		"""
		system("cls")
		print("=== REPORTE DE INGRESOS (PAGOS RECIBIDOS) ===")

		# Filtra solo los registros que tienen valor de pago
		registros_pagados = []
		for p in self.parqueaderos:
			if p.valor_pagar and p.valor_pagar > 0:
				registros_pagados.append(p)
		
		if not registros_pagados:
			print("No hay registros de pagos de parqueo.")
			input("Enter para continuar...")
			return

		# Calcula el total de ingresos
		total_ingresos = 0
		for p in registros_pagados:
			total_ingresos += p.valor_pagar

		print(f" Ingresos totales recibidos: ${total_ingresos}")

		print("\n--- Detalle de pagos ---")
		# Muestra el detalle de cada pago recibido
		for parqueo in registros_pagados:
			print("-------------------------")
			print(f"Código: {parqueo.codigo_parqueo}")
			print(f"Placa: {parqueo.placa}")
			print(f"Fecha Salida: {parqueo.fecha} / {parqueo.hora_salida}")
			print(f"Propietario: {parqueo.nombre_propietario}")
			print(f"Valor pagado: ${parqueo.valor_pagar}")

		input("Enter para continuar...")

# ====================== MAIN (PUNTO DE ENTRADA) ======================
if __name__ == "__main__":
	"""
	Punto de entrada principal del programa.
	Crea una instancia del menú y ejecuta el sistema.
	"""
	menu = Menu()  # Crea una instancia de la clase Menu
	menu.mostrar_menu()  # Inicia el programa mostrando el menú principal